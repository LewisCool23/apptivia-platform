# Apptivia Backend

Express.js backend for Apptivia Platform.
