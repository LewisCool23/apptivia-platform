# Apptivia Frontend

React frontend for Apptivia Platform.
